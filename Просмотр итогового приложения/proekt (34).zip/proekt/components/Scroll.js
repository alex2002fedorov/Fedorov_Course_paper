import * as React from 'react';
import { View, Image, Text, ScrollView, Dimensions, StyleSheet } from 'react-native';

const {width}= Dimensions.get('window');
const height = width*0.55;
const w1 =width *0.9;


export default class App extends React.Component{
  render(){
     // Карусель из картинок полученных с других страниц
    return(
      <View style={{marginTop: '5%', width,height}}>
      <ScrollView pagingEnabled horizontal onScroll={this.change} persistentScrollbar={false} indicatorStyle='white' style={{width:w1 ,height, alignSelf:'center', borderRadius:10, }}>
      {
        this.props.images.map((image,index) => (
          <Image source={{uri: image}} style={{width:w1, height, resizeMode:'cover',borderRadius:10,}}/>
        ))
      }
      </ScrollView>
      </View>
    )
  }
}